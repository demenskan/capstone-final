import jwt
import hashlib
import logging
import json

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    """
    This function gets a mask and returns a cidr prefix
    there must be a valid JWT on the header
    """
    jwtKey="my2w7wjd7yXF64FIADfJxNs1oupTGAuW"
    logger.info(event)
    response = {
        "statusCode": 200,
        "body" : json.dumps("hello")
    }
    return response


